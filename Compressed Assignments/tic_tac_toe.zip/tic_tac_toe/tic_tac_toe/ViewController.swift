//
//  ViewController.swift
//  tic_tac_toe
//
//  Created by Greg Friedlander on 11/1/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var turn = 0
    var board: [[Int]] = []

    @IBOutlet var buttonCollection: [UIButton]!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var winnerLabel: UILabel!
    
    @IBAction func touchSquare(_ sender: UIButton) {
        if turn == 0 {
            sender.backgroundColor = UIColor.blue
            updateBlueBoard(tag: sender.tag)
            turn = 1
            if checkWinnerDiagonal() || checkWinnerVertical() || checkWinnerHorizontal() {
                winnerLabel.text = "Congrats, Blue Wins"
            }
        } else {
            sender.backgroundColor = UIColor.red
            updateRedBoard(tag: sender.tag)
            turn = 0
            if checkWinnerDiagonal() || checkWinnerVertical() || checkWinnerHorizontal() {
                winnerLabel.text = "Congrats, Red Wins"
            }
        }
        
    }
    
    @IBAction func resetBoard(_ sender: UIButton) {
        for button in buttonCollection{
            button.backgroundColor = UIColor.gray
        }
        winnerLabel.text = ""
    }
    
    func populateArray () {
        board.append([0,0,0])
        board.append([0,0,0])
        board.append([0,0,0])
    }
    
    func updateBlueBoard(tag: Int) {
        if tag == 1 {
            board[0][0] = 1
        }
        else if tag == 2 {
            board[0][1] = 1
        }
        else if tag == 3 {
            board[0][2] = 1
        }
        else if tag == 4 {
            board[1][0] = 1
        }
        else if tag == 5 {
            board[1][1] = 1
        }
        else if tag == 6 {
            board[1][2] = 1
        }
        else if tag == 7 {
            board[2][0] = 1
        }
        else if tag == 8 {
            board[2][1] = 1
        }
        else {
            board[2][2] = 1
        }
    }
    
    func updateRedBoard(tag: Int) {
        if tag == 1 {
            board[0][0] = 2
        }
        else if tag == 2 {
            board[0][1] = 2
        }
        else if tag == 3 {
            board[0][2] = 2
        }
        else if tag == 4 {
            board[1][0] = 2
        }
        else if tag == 5 {
            board[1][1] = 2
        }
        else if tag == 6 {
            board[1][2] = 2
        }
        else if tag == 7 {
            board[2][0] = 2
        }
        else if tag == 8 {
            board[2][1] = 2
        }
        else {
            board[2][2] = 2
        }
    }

    func checkWinnerHorizontal() -> Bool {
        if board[0][0] == board[0][1] && board[0][0] == board[0][2] && board[0][0] != 0 {
            return true
        }
        if board[1][0] == board[1][1] && board[1][0] == board[1][2] && board[1][0] != 0 {
            return true
        }
        if board[2][0] == board[2][1] && board[2][0] == board[2][2] && board[2][0] != 0 {
            return true
        }
        return false
    }
    
    func checkWinnerVertical() -> Bool {
        if board[0][0] == board[1][0] && board[0][0] == board[2][0] && board[0][0] != 0 {
            return true
        }
        if board[0][1] == board[1][1] && board[0][1] == board[2][1] && board[0][1] != 0 {
            return true
        }
        if board[0][2] == board[1][2] && board[0][2] == board[2][2] && board[0][2] != 0 {
            return true
        }
        return false
    }
    
    func checkWinnerDiagonal() -> Bool {
        if board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] != 0 {
            return true
        }
        if board[0][2] == board[1][1] && board[0][2] == board[2][0] && board[0][2] != 0 {
            return true
        }
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateArray()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

