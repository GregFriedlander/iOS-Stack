//
//  ViewController.swift
//  Aging_People
//
//  Created by Greg Friedlander on 11/6/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var people = ["George", "Betty", "Fran", "Joe", "Helda", "Winfred", "Zed", "Sara", "Jeffy", "Abraham", "Anna", "Melinda"]
    
    var age = Int(arc4random_uniform(90)+5)
    
    @IBOutlet weak var tableView: UITableView!
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        
        cell.textLabel?.text = String(people[indexPath.row])
        cell.detailTextLabel?.text = String(Int(arc4random_uniform(95)+5)) + " years old"
        
        return cell
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

