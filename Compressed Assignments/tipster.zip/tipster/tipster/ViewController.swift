//
//  ViewController.swift
//  tipster
//
//  Created by Greg Friedlander on 11/1/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var totalBill: UILabel!
    @IBOutlet weak var decimalKey: UIButton!
    
    @IBOutlet weak var percentTip1: UILabel!
    @IBOutlet weak var percentTip2: UILabel!
    @IBOutlet weak var percentTip3: UILabel!
    
    
    @IBOutlet weak var tipAmount1: UILabel!
    @IBOutlet weak var tipAmount2: UILabel!
    @IBOutlet weak var tipAmount3: UILabel!
    
    @IBOutlet weak var amountEach1: UILabel!
    @IBOutlet weak var amountEach2: UILabel!
    @IBOutlet weak var amountEach3: UILabel!
    
    
    @IBOutlet weak var tipSlider: UISlider!
    @IBOutlet weak var groupSizeSlider: UISlider!
    @IBOutlet weak var groupSizeLabel: UILabel!
    
    
    @IBOutlet var calculatorButtons: [UIButton]!
    
    
    
    // how to input your bill
    
    @IBAction func billAmount(_ sender: UIButton) {
        
        if totalBill.text == "0" && sender.tag < 10 {
            totalBill.text = String(sender.tag)
        }
        else if totalBill.text == "0" && sender.tag == 11 {
            totalBill.text = "0."
            sender.isEnabled = false
        }
        else if sender.tag < 10 {
            if let billAmount = totalBill.text {
               totalBill.text = billAmount + String(sender.tag)
            }
        }
        else if sender.tag == 11 {
            if let billAmount = totalBill.text {
                totalBill.text = billAmount + "."
                sender.isEnabled = false
            }
        }
        else if sender.tag == 10 {
            totalBill.text = "0"
            decimalKey.isEnabled = true
        }
        crunchNumbers()
        
    }
    
    
    @IBAction func tipSlider(_ sender: UISlider) {
        
        percentTip1.text = String(round(tipSlider.value)) + "%"
        percentTip2.text = String(round(tipSlider.value) + 5) + "%"
        percentTip3.text = String(round(tipSlider.value) + 10) + "%"
        
        crunchNumbers()
        
    }
    
    @IBAction func groupSlider(_ sender: UISlider) {
        
        groupSizeLabel.text = "Group Size: " + String(Int(round(groupSizeSlider.value)))
        
        crunchNumbers()
    }
    
    func crunchNumbers() {
        if let totalBillString = totalBill.text {
            let total = Double(totalBillString)
            let tip = Double(round(tipSlider.value))
            let group = Double(round(groupSizeSlider.value))
            let minimumTip = round((total! * (tip/100)) * 100)/100
            let minPerPerson = (round(((total! + minimumTip)/group) * 100))/100
            let mediumTip = round((total! * ((tip + 5)/100))*100)/100
            let medPerPerson = (round(((total! + mediumTip)/group)*100))/100
            let maximumTip = round((total! * ((tip + 10)/100))*100)/100
            let maxPerPerson = (round(((total! + mediumTip)/group)*100))/100
            tipAmount1.text = String(minimumTip)
            tipAmount2.text = String(mediumTip)
            tipAmount3.text = String(maximumTip)
            amountEach1.text = String(minPerPerson)
            amountEach2.text = String(medPerPerson)
            amountEach3.text = String(maxPerPerson)
            
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        totalBill.text = "0"
        
        percentTip1.text = "10%"
        percentTip2.text = "15%"
        percentTip3.text = "20%"
        
        tipAmount1.text = "0.00"
        tipAmount2.text = "0.00"
        tipAmount3.text = "0.00"
        
        amountEach1.text = "0.00"
        amountEach2.text = "0.00"
        amountEach3.text = "0.00"
        
        groupSizeLabel.text = "Group Size: 1"
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

