//
//  ViewController.swift
//  Cold_Call
//
//  Created by Greg Friedlander on 10/31/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numberLabel: UILabel!
    
    var currentIndex = 0
    
    let nameBank = ["Gregorio", "Eddie", "Marissa", "Andrea", "Michael"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        updateUI()
    }
    
//    func updateUI() {
//        nameLabel.text = nameBank[currentIndex]
//    }
    
    @IBAction func coldCallButtonPressed(_ sender: UIButton) {
        
        
        let number = Int(arc4random_uniform(5)+1)
        let show_number = String(number)
        numberLabel.text = show_number
        
        if number <= 2 {
            numberLabel.textColor = UIColor.red
        } else if number == 5 {
            numberLabel.textColor = UIColor.green
        } else {
            numberLabel.textColor = UIColor.orange
        }
        
        currentIndex = Int(arc4random_uniform(UInt32(nameBank.count)))
        nameLabel.text = nameBank[currentIndex]
        
//        updateUI()
    }
    
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

