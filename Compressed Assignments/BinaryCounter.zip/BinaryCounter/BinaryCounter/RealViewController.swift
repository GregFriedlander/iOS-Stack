//
//  RealViewController.swift
//  BinaryCounter
//
//  Created by Greg Friedlander on 11/9/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class RealViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var tableView: UITableView!
    
    var num = 1
    var total = 0
    
    @IBOutlet weak var totalLabel: UILabel!
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cCell") as! CustomCell
        cell.numberLabel.text = String(describing: Decimal(num) * pow(10, indexPath.row))
        cell.contentView.layer.borderColor = UIColor.white.cgColor
        cell.contentView.layer.borderWidth = 1
        cell.delegate = self
        
        
        return cell
        
        
    }
    
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 16
        
    }

    func plusButtonPressed(_ sender: String) {
        total = total + Int(sender)!
        totalLabel.text = "Total:" + String(total)
        
        
    }
    
    func minusButtonPressed(_ sender: String) {
        total = total - Int(sender)!
        totalLabel.text = "Total:" + String(total)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        totalLabel.text = "Total:" + String(total)
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
