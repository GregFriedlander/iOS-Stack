//
//  CustomCell.swift
//  BinaryCounter
//
//  Created by Greg Friedlander on 11/9/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

class CustomCell: UITableViewCell {
    
    var delegate: RealViewController?
    
    
   
    @IBOutlet weak var plusButton: UIButton!
    
    
    @IBOutlet weak var minusButton: UIButton!
    
    @IBOutlet weak var numberLabel: UILabel!
    
    
    @IBAction func plusButtonPressed(_ sender: UIButton) {
        delegate?.plusButtonPressed(numberLabel.text!)
    }
    
    @IBAction func minusButtonPressed(_ sender: UIButton) {
        delegate?.minusButtonPressed(numberLabel.text!)
        
    }
    
    
}
