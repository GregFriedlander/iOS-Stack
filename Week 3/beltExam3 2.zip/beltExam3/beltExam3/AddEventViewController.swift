//
//  AddEventViewController.swift
//  beltExam3
//
//  Created by Greg Friedlander on 11/22/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class AddEventViewController: UIViewController {
    
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var infoTextView: UITextView!
    @IBOutlet weak var eventTimePicker: UIDatePicker!
    
    var delegate: AddEventViewControllerDelegate?
    var indexPath: NSIndexPath?
    var editTitle: String?
    var editInfo: String?
    
    @IBAction func saveButtonPressed(_ sender: UIButton) {
        
        let title = titleTextField.text
        let info = infoTextView.text
        let time = eventTimePicker.date
        delegate?.itemSaved(by: self, with: title!, with: info!, with: time, at: indexPath)
    }
    
    @IBAction func cancelButtonPressed(_ sender: UIButton) {
        delegate?.cancelButtonPressed(by: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        eventTimePicker.date = Date()
        titleTextField.text = editTitle
        infoTextView.text = editInfo 

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
