//
//  AddEventViewControllerDelegate.swift
//  beltExam3
//
//  Created by Greg Friedlander on 11/22/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

protocol AddEventViewControllerDelegate: class {
    func itemSaved(by controller: AddEventViewController, with title: String, with info: String, with time: Date, at indexPath: NSIndexPath?)
    func cancelButtonPressed(by controller: AddEventViewController)
}
