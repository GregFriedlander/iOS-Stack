//
//  BeastToDoTableViewController.swift
//  Beast_BeltExam
//
//  Created by Greg Friedlander on 11/17/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit
import CoreData

class BeastToDoTableViewController: UITableViewController, AddItemViewControllerDelegate {
    
    var items = [BeastItem]()
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func fetchIncompleteItems() {
        
        let customFetch: NSFetchRequest<BeastItem> = BeastItem.fetchRequest()
        
        let incompletePred = NSPredicate(format: "completed == false")
        
        customFetch.predicate = incompletePred
        
        var incomplete_arr: [BeastItem] = [BeastItem]()
        
        do {
            let customRequest = try managedObjectContext.fetch(customFetch) as [BeastItem]
            customRequest.forEach({
                item in
                incomplete_arr.append(item)
            })
            self.items = incomplete_arr
            tableView.reloadData()
        } catch {
            print("\(error)")
        }    
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchIncompleteItems()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! CustomCell

        cell.beastLabel.text = items[indexPath.row].item
        cell.ip = indexPath as NSIndexPath
        cell.delegate = self

        return cell
    }
    
    func cancelButtonPressed(by controller: AddItemViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    func itemSaved(by controller: AddItemViewController, with item: String, at indexPath: NSIndexPath?) {
        
        if let ip = indexPath {
            let beastItem = items[ip.row]
            beastItem.item = item
        }
        else {
            let beastItem = BeastItem(context: managedObjectContext)
            beastItem.item = item
            beastItem.completed = false
            beastItem.dateCompleted = nil
        }
        do {
            try managedObjectContext.save()
        }catch {
            print("\(error)")
        }
        dismiss(animated: true, completion: nil)
        fetchIncompleteItems()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (sender as? UIBarButtonItem) != nil {
            let navigationController = segue.destination as! UINavigationController
            let addItemViewController = navigationController.topViewController as! AddItemViewController
            addItemViewController.delegate = self
        } else {
            let navigationController = segue.destination as! UINavigationController
            let addItemViewController = navigationController.topViewController as! AddItemViewController
            addItemViewController.delegate = self
            
            let indexPath = sender as! NSIndexPath
            let item = items[indexPath.row]
            addItemViewController.editItem = item.item!
            addItemViewController.indexPath = indexPath
            
        }
    }
 

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "addItemSegue", sender: indexPath)
    }

   
   
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let item = items[indexPath.row]
        managedObjectContext.delete(item)
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        items.remove(at: indexPath.row)
        tableView.reloadData()

    }
    
    func beastButtonPressed(_ sender: NSIndexPath) {
        print("is anything happening")
        let beastItem = self.items[sender.row]
        beastItem.completed = !beastItem.completed
        beastItem.dateCompleted = Date() as NSDate
                
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        print(beastItem.dateCompleted)
        fetchIncompleteItems()
    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
