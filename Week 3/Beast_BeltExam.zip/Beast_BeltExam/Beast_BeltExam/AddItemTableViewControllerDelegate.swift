//
//  AddItemTableViewControllerDelegate.swift
//  Beast_BeltExam
//
//  Created by Greg Friedlander on 11/17/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

protocol AddItemViewControllerDelegate: class {
    
    func itemSaved(by controller: AddItemViewController, with item: String, at indexPath: NSIndexPath?)
    func cancelButtonPressed(by controller: AddItemViewController)
    
}
