//
//  AddItemViewController.swift
//  Beast_BeltExam
//
//  Created by Greg Friedlander on 11/17/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class AddItemViewController: UIViewController {

    var delegate: AddItemViewControllerDelegate?
    
    var editItem: String?
    var indexPath: NSIndexPath?
    
    
    @IBOutlet weak var itemText: UITextField!
    
    
    @IBAction func cancellButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.cancelButtonPressed(by: self)
    }
    
    @IBAction func doneButtonPressed(_ sender: UIBarButtonItem) {
        let item = itemText.text
        delegate?.itemSaved(by: self, with: item!, at: indexPath)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        itemText.text = editItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
