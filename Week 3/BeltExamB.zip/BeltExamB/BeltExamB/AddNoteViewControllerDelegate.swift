//
//  AddNoteViewControllerDelegate.swift
//  BeltExamB
//
//  Created by Greg Friedlander on 11/21/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

protocol AddNoteViewControllerDelegate: class {
    func itemSaved(by controller: AddNoteViewController, with note: String, with date: Date, at indexPath: NSIndexPath?)
}
