//
//  AddNoteViewController.swift
//  BeltExamB
//
//  Created by Greg Friedlander on 11/21/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class AddNoteViewController: UIViewController {
    
    var delegate: AddNoteViewControllerDelegate?
    var indexPath: NSIndexPath?
    var editNote: String?

    @IBOutlet weak var notesTextView: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        notesTextView.text = editNote

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        if self.isMovingFromParentViewController {
            print("back button pressed")
            let notes = notesTextView.text
            let date = Date()
            
            delegate?.itemSaved(by: self, with: notes!, with: date, at: indexPath)
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
