//
//  NotesTableViewController.swift
//  BeltExamB
//
//  Created by Greg Friedlander on 11/21/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit
import CoreData

class NotesTableViewController: UITableViewController, AddNoteViewControllerDelegate, UISearchResultsUpdating, UISearchBarDelegate {
    
    var notes = [Notes]()
    var filteredNotes = [Notes]()
//    var resultsSearchController = UISearchController()
    var searchController = UISearchController(searchResultsController: nil)
    var resultsController = UITableViewController()
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func fetchAllNotes() {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Notes")
        request.sortDescriptors = [NSSortDescriptor(key: "editedDate", ascending: false)]
        do {
            let result = try managedObjectContext.fetch(request)
            notes = result as! [Notes]
        } catch {
            print("\(error)")
        }
        
        tableView.reloadData()
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let customFetch: NSFetchRequest<Notes> = Notes.fetchRequest()
        customFetch.predicate = NSPredicate(format: "note = %@", searchController.searchBar.text!)
        do {
            let filteredReq = try managedObjectContext.fetch(customFetch) as [Notes]
            filteredNotes = filteredReq
        } catch {
            print(error)
        }
        tableView.reloadData()
    }

    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllNotes()
        searchController = UISearchController(searchResultsController: resultsController)
//        tableView.tableHeaderView = searchController.searchBar
        searchController.searchResultsUpdater = self
        
        resultsController.tableView.delegate = self
        resultsController.tableView.dataSource = self
        
        
        
//        definesPresentationContext = true

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.searchController.isActive {
            return self.filteredNotes.count
        }
        
        return notes.count
    }

    func itemSaved(by controller: AddNoteViewController, with note: String, with date: Date, at indexPath: NSIndexPath?) {
        
        if let ip = indexPath {
            let oldNote = notes[ip.row]
            oldNote.note = note
            oldNote.editedDate = date as NSDate?
        }
        else {
            let newNote = NSEntityDescription.insertNewObject(forEntityName: "Notes", into: managedObjectContext) as! Notes
            
            newNote.note = note
            newNote.editedDate = date as NSDate?
            notes.append(newNote)
        }
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        self.navigationController?.popToRootViewController(animated: true)
        print("The item saved")
        fetchAllNotes()

        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (sender as? UIBarButtonItem) != nil {
            let addNoteViewController = segue.destination as! AddNoteViewController
            addNoteViewController.delegate = self
        } else {
            let addNoteViewController = segue.destination as! AddNoteViewController
            addNoteViewController.delegate = self
            
            let indexPath = sender as! NSIndexPath
            let note = notes[indexPath.row]
            addNoteViewController.indexPath = indexPath
            addNoteViewController.editNote = note.note!
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "noteCell", for: indexPath)
        let thisNote: Notes
        
        if self.searchController.isActive {
            thisNote = filteredNotes[indexPath.row]
            cell.textLabel?.text = filteredNotes[indexPath.row].note
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy"
            let dateString = dateFormatter.string(from: thisNote.editedDate! as Date)
            cell.detailTextLabel?.text = dateString
        }
        else {
            thisNote = notes[indexPath.row]
            
            
            cell.textLabel?.text = thisNote.note
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy"
            let dateString = dateFormatter.string(from: thisNote.editedDate! as Date)
            cell.detailTextLabel?.text = dateString
        }
        
        
        return cell
    }
   
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "addSegue", sender: indexPath)
        
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
            let note = notes[indexPath.row]
            managedObjectContext.delete(note)
        
            do {
                try managedObjectContext.save()
            } catch {
                print("\(error)")
            }
            notes.remove(at: indexPath.row)
            tableView.reloadData()

        }
    
}
