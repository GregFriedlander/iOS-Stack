//
//  CustomCell.swift
//  Beast_BeltExam
//
//  Created by Greg Friedlander on 11/17/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

class CustomCell: UITableViewCell {
    
    var delegate: BeastToDoTableViewController?
    var ip: NSIndexPath?
    
    @IBOutlet weak var beastLabel: UILabel!
    
    
    @IBAction func beastButtonPressed(_ sender: UIButton) {
        delegate?.beastButtonPressed(ip!)
    
        }

}
