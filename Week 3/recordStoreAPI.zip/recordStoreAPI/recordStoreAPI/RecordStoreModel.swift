//
//  RecordStoreModel.swift
//  recordStoreAPI
//
//  Created by Greg Friedlander on 11/20/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation

class RecordStoreModel {
    
    static func getAllRecords(completionHandler:@escaping (_ data: Data?, _ response: URLResponse?, _ error: Error?) -> Void) {
        
        let url = URL(string: "http://localhost:8000/admin/admin_portal/data/records")
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: url!, completionHandler: completionHandler)
        
        task.resume()
    
    }
}
