//
//  IncompleteCustomCell.swift
//  beltExam3
//
//  Created by Greg Friedlander on 11/22/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

class IncompleteCustomCell: UITableViewCell {
    
    var delegate: MyEventsTableViewController?
    var ip: NSIndexPath?
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    
    
    @IBAction func editButtonPressed(_ sender: UIButton) {
        delegate?.editButtonPressed(by: self, at: ip!)
    }
    
}
