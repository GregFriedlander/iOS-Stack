//
//  MyEventsTableViewController.swift
//  beltExam3
//
//  Created by Greg Friedlander on 11/22/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit
import CoreData

class MyEventsTableViewController: UITableViewController, AddEventViewControllerDelegate {
    
    var incompleteEvents = [Events]()
    var completeEvents = [Events]()
    var events = [Events]()
    
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    
    let sections = ["Incomplete", "Complete"]

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchIncompleteItems()
        fetchCompleteItems()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        fetchIncompleteItems()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    func fetchIncompleteItems() {
        
        let customFetch: NSFetchRequest<Events> = Events.fetchRequest()
        
        let incompletePred = NSPredicate(format: "completed == false")
        
        customFetch.predicate = incompletePred
        customFetch.sortDescriptors = [NSSortDescriptor(key: "time", ascending: true)]
        
        do {
            let customRequest = try managedObjectContext.fetch(customFetch) as [Events]
            incompleteEvents = customRequest
            tableView.reloadData()
        } catch {
            print("\(error)")
        }
        tableView.reloadData()
    }

    func fetchCompleteItems() {
        
        let customFetch: NSFetchRequest<Events> = Events.fetchRequest()
        
        let completePred = NSPredicate(format: "completed == true")
        
        customFetch.predicate = completePred
        customFetch.sortDescriptors = [NSSortDescriptor(key: "time", ascending: true)]
        
        do {
            let customRequest = try managedObjectContext.fetch(customFetch) as [Events]
            completeEvents = customRequest
            tableView.reloadData()
        } catch {
            print("\(error)")
        }
        tableView.reloadData()
    }

  

    override func numberOfSections(in tableView: UITableView) -> Int {
       
        return 2
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section]
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 {
            return incompleteEvents.count
        }
        else {
            return completeEvents.count
        }
    }
    
    func itemSaved(by controller: AddEventViewController, with title: String, with info: String, with time: Date, at indexPath: NSIndexPath?) {
        if let ip = indexPath {
            let oldEvent = incompleteEvents[ip.row]
            oldEvent.title = title
            oldEvent.info = info
            oldEvent.time = time as NSDate?
        }
        else {
            let newEvent = NSEntityDescription.insertNewObject(forEntityName: "Events", into: managedObjectContext) as! Events
            
            newEvent.title = title
            newEvent.info = info
            newEvent.time = time as NSDate?
            newEvent.completed = false
        }
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        self.navigationController?.popToRootViewController(animated: true)
        fetchIncompleteItems()

    }
    
    func cancelButtonPressed(by controller: AddEventViewController) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "incompleteCell", for: indexPath) as! IncompleteCustomCell
            cell.delegate = self
            let myEvents: Events
            myEvents = incompleteEvents[indexPath.row]
            cell.titleLabel.text = myEvents.title
            cell.ip = indexPath as NSIndexPath
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            let dateString = dateFormatter.string(from: myEvents.time as! Date)
            cell.timeLabel.text = dateString
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! CompleteCustomCell
            cell.delegate = self
            let myEvents: Events
            myEvents = completeEvents[indexPath.row]
            cell.titleLabel.text = myEvents.title
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            let dateString = dateFormatter.string(from: myEvents.time as! Date)
            cell.timeLabel.text = dateString
            
            return cell
        }
        
    }
    
    func editButtonPressed(by controller: IncompleteCustomCell, at indexPath: NSIndexPath){
        performSegue(withIdentifier: "addSegue", sender: indexPath)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (sender as? UIBarButtonItem) != nil {
            let addEventViewController = segue.destination as! AddEventViewController
            addEventViewController.delegate = self
        } else {
            let addEventViewController = segue.destination as! AddEventViewController
            addEventViewController.delegate = self
            
            let indexPath = sender as! NSIndexPath
            let event = incompleteEvents[indexPath.row]
            addEventViewController.editTitle = event.title
            addEventViewController.editInfo = event.info
            addEventViewController.indexPath = indexPath
            addEventViewController.navigationItem.title = event.title

        }
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            let event = incompleteEvents[indexPath.row]
            managedObjectContext.delete(event)
            
            do {
                try managedObjectContext.save()
            } catch {
                print("\(error)")
            }
            incompleteEvents.remove(at: indexPath.row)
            fetchIncompleteItems()
        }
        else {
            let event = completeEvents[indexPath.row]
            managedObjectContext.delete(event)
            
            do {
                try managedObjectContext.save()
            } catch {
                print("\(error)")
            }
            completeEvents.remove(at: indexPath.row)
            fetchIncompleteItems()

            
        }
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            let myEvent = incompleteEvents[indexPath.row]
            myEvent.completed = true
            
            do {
                try managedObjectContext.save()
            } catch {
                print("\(error)")
            }

        }
        else {
            let myEvent = completeEvents[indexPath.row]
            myEvent.completed = false
            
            do {
                try managedObjectContext.save()
            } catch {
                print("\(error)")
            }
        }
        fetchIncompleteItems()
        fetchCompleteItems()
        
    }
    
}
