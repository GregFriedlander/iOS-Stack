//
//  TableViewController.swift
//  ToDoListApp
//
//  Created by Greg Friedlander on 11/9/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController {
    
    var items = [TodoListItem3]()
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllItems()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func fetchAllItems() {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "TodoListItem3")
        do {
            let result = try managedObjectContext.fetch(request)
            items = result as! [TodoListItem3]
        } catch {
            print("\(error)")
        }
        
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        
        performSegue(withIdentifier: "addSegue", sender: indexPath)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (sender as? UIBarButtonItem) != nil {
            
            let addItem = segue.destination as! AddEventViewController
            addItem.delegate = self
            
        } else {
            
        }
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath) as! CustomCell
        let todoItem = items[indexPath.row]
        cell.titleLabel.text = items[indexPath.row].title
        cell.descriptionLabel.text = items[indexPath.row].notes
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let dateString = dateFormatter.string(from: todoItem.completeDate as! Date)
        cell.dateLabel.text = dateString
        
        if todoItem.isCompleted == true {
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }
        
        
        return cell
    }
    
    func addItem(by controller: AddEventViewController, with title: String, with notes: String, with completeDate: Date) {
        
        let item = NSEntityDescription.insertNewObject(forEntityName: "TodoListItem3", into: managedObjectContext) as! TodoListItem3
        item.title = title
        item.notes = notes
        item.completeDate = completeDate as NSDate?
        item.isCompleted = false
        items.append(item)
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
        
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let todoItem = self.items[indexPath.row]
        todoItem.isCompleted = !todoItem.isCompleted
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        let cell = tableView.cellForRow(at: indexPath)
        if todoItem.isCompleted {
            cell?.accessoryType = .checkmark
        } else {
            cell?.accessoryType = .none
        }

        
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let item = items[indexPath.row]
        managedObjectContext.delete(item)
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        items.remove(at: indexPath.row)
        tableView.reloadData()
        
        
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

 
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
