//
//  AddEventViewControllerDelegate.swift
//  ToDoListApp
//
//  Created by Greg Friedlander on 11/11/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

protocol AddEventViewControllerDelegate: class {
    func addItem(by controller: AddEventViewController, with title: String, with description: String)
}
