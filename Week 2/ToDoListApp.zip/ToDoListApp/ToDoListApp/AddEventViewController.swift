//
//  AddEventViewController.swift
//  ToDoListApp
//
//  Created by Greg Friedlander on 11/11/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class AddEventViewController: UIViewController {

    
    @IBOutlet weak var todoTitleLabel: UITextField!
    @IBOutlet weak var todoDesciptionTextView: UITextView!
    @IBOutlet weak var todoDatePicker: UIDatePicker!
    @IBOutlet weak var addButton: UIButton!
    
    var delegate: TableViewController?
    
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        
        let title = todoTitleLabel.text!
        let notes = todoDesciptionTextView.text!
        let completeDate = todoDatePicker.date
        delegate?.addItem(by: self, with: title, with: notes, with: completeDate)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
