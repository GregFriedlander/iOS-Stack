//
//  FinalDirectionTableViewControllerDelegate.swift
//  Direction_Assignment
//
//  Created by Greg Friedlander on 11/7/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

protocol FinalDirectionTableViewControllerDelegate: class {
    
    func directionButtonPressed(by controller: FinalDirectionTableViewController)
    
}
