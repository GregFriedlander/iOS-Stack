//
//  FinalDirectionTableViewController.swift
//  Direction_Assignment
//
//  Created by Greg Friedlander on 11/7/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class FinalDirectionTableViewController: UIViewController {

    weak var delegate: FinalDirectionTableViewControllerDelegate?
    
    var buttontitle: String?
    
    
    @IBOutlet weak var mainButton: UIButton!
    
    @IBAction func directionButtonPressed(_ sender: UIButton) {
        
        delegate?.directionButtonPressed(by: self)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mainButton.setTitle(buttontitle, for: .normal)
        
            }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
}
