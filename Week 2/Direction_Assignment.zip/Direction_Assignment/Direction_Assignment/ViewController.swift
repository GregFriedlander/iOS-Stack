//
//  ViewController.swift
//  Direction_Assignment
//
//  Created by Greg Friedlander on 11/7/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class ViewController: UIViewController, FinalDirectionTableViewControllerDelegate {


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (sender as? UIButton) != nil {
            
            let finalDirection = segue.destination as! FinalDirectionTableViewController
            finalDirection.delegate = self

            let thebutton = sender as! UIButton
            let buttontitle = thebutton.titleLabel!.text
            finalDirection.buttontitle = buttontitle
        
            
        } else {
            
        }
        
    }
    
    
    @IBAction func initialButtonPressed(_ sender: UIButton) {
        
        performSegue(withIdentifier: "Direction", sender: sender)
        
    }
    
    func directionButtonPressed(by controller: FinalDirectionTableViewController) {
        dismiss(animated: true, completion: nil)
    }


}

