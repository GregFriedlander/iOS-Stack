//
//  AddItemViewController.swift
//  toDo2
//
//  Created by Greg Friedlander on 11/12/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class AddItemViewController: UIViewController {
    
    var delegate: ToDoTableViewController?
    
    @IBOutlet weak var todoTitleLabel: UITextField!
    @IBOutlet weak var todoNotesTextField: UITextView!
    @IBOutlet weak var todoDatePicker: UIDatePicker!
    @IBOutlet weak var addButton: UIButton!
    
   
    @IBAction func addButtonPressed(_ sender: UIButton) {
        
        let title = todoTitleLabel.text!
        let notes = todoNotesTextField.text!
        let completeDate = todoDatePicker.date
        delegate?.addItem(by: self, with: title, with: notes, with: completeDate)
        
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
