//
//  ToDoTableViewController.swift
//  toDo2
//
//  Created by Greg Friedlander on 11/12/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit
import CoreData

class ToDoTableViewController: UITableViewController {
    
    
    var items = [TodoItems] ()
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func fetchAllItems() {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "TodoItems")
        do {
            let result = try managedObjectContext.fetch(request)
            items = result as! [TodoItems]
        } catch {
            print("\(error)")
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllItems()
            }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return items.count
    }
    
    func addItem(by controller: AddItemViewController, with title: String, with notes: String, with completeDate: Date) {
        
        let item = NSEntityDescription.insertNewObject(forEntityName: "TodoItems", into: managedObjectContext) as! TodoItems
        
        item.title = title
        item.notes = notes
        item.completeDate = completeDate as NSDate?
        item.isCompleted = false
        items.append(item)
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
        
    }
    
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let addItem = segue.destination as! AddItemViewController
        addItem.delegate = self
        
        }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! CustomCell
        let todoItem = items[indexPath.row]
        cell.titleLabel.text = items[indexPath.row].title
        cell.notesLabel.text = items[indexPath.row].notes
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let dateString = dateFormatter.string(from: todoItem.completeDate as! Date)
        cell.dateLabel.text = dateString
        
        if todoItem.isCompleted{
            cell.accessoryType = .checkmark
        } else {
            cell.accessoryType = .none
        }

        return cell
    }
    

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let todoItem = self.items[indexPath.row]
        todoItem.isCompleted = !todoItem.isCompleted
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        let cell = tableView.cellForRow(at: indexPath)
        if todoItem.isCompleted{
            cell?.accessoryType = .checkmark
        } else {
            cell?.accessoryType = .none
        }
        
    }


    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let item = items[indexPath.row]
        managedObjectContext.delete(item)
        
        do {
            try managedObjectContext.save()
        } catch {
            print("\(error)")
        }
        
        items.remove(at: indexPath.row)
        tableView.reloadData()
        
    }
    

}
