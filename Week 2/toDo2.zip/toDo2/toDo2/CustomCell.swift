//
//  CustomCell.swift
//  toDo2
//
//  Created by Greg Friedlander on 11/12/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

class CustomCell: UITableViewCell {
    
    var delegate: ToDoTableViewController?
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var notesLabel: UILabel!
    
    
}
