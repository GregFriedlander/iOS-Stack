//
//  ViewController.swift
//  Madlibs
//
//  Created by Greg Friedlander on 11/7/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class ViewController: UIViewController, SubmitViewControllerDelegate {

    
    
    @IBOutlet weak var madlibLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        madlibLabel.text = "..."
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let finalDestination = segue.destination as! SubmitViewController
        finalDestination.delegate = self
        
    }
    
    func submitMadlib(by controller: SubmitViewController, with adj: String, with verb1: String, with verb2: String, with noun: String) {
        madlibLabel.text = "We are having a perfectly \(adj) time now. Later we will \(verb1) and \(verb2) in the \(noun)"
        dismiss(animated: true, completion: nil)
    }

}

