//
//  SubmitViewController.swift
//  Madlibs
//
//  Created by Greg Friedlander on 11/7/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import UIKit

class SubmitViewController: UIViewController {
    
    weak var delegate: SubmitViewControllerDelegate?
    
    
    @IBOutlet weak var adjTextField: UITextField!
    @IBOutlet weak var verb1TextField: UITextField!
    @IBOutlet weak var verb2TextField: UITextField!
    @IBOutlet weak var nounTextField: UITextField!
    
    
    @IBAction func submitButtonPressed(_ sender: UIButton) {
        
        let adj = adjTextField.text!
        let verb1 = verb1TextField.text!
        let verb2 = verb2TextField.text!
        let noun = nounTextField.text!
        delegate?.submitMadlib(by: self, with: adj, with: verb1, with: verb2, with: noun)
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
