//
//  SubmitViewControllerDelegate.swift
//  Madlibs
//
//  Created by Greg Friedlander on 11/7/17.
//  Copyright © 2017 Greg Friedlander. All rights reserved.
//

import Foundation
import UIKit

protocol SubmitViewControllerDelegate: class {
    
    func submitMadlib(by controller: SubmitViewController, with adj: String, with verb1: String, with verb2: String, with noun: String)
    
}
